package com.min.edu.main;
public class Card_Main {
	public static void main(String[] args) throws InterruptedException {		
		Card_Process cp = new Card_Process();
		cp.start();

	}
}